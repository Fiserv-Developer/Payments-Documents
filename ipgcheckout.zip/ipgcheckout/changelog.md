# ChangeLog

## [1.0.2] - 2026-04-29

### Security
- Removed default variables to resolve false positive security findings

### Added
- 'iDEAL | Wero' as a pre-selection option
- Localization packs for DE, FR, NL, ES

### Changed
- Safer refund handling

## [1.0.1] - 2026-02-06

### Changed
- Fixed tax issue
- Masked secret keys
- Fixed vat calculation

