<?php

require_once dirname(__FILE__) . '/../../vendor/autoload.php';

/**
 * Called on success. Checks if cart was paid. Validated cart if paid.
 */
class IPGCheckoutSuccessModuleFrontController extends ModuleFrontController
{
    public $module;
    private $handler;

    public function init()
    {
        parent::init();
        $this->handler = new CheckoutRequestHandler(
            Configuration::get(IPGCheckout::STORE_ID_KEY),
            Configuration::get(IPGCheckout::API_KEY_KEY),
            Configuration::get(IPGCheckout::SECRET_KEY)
        );
    }

    public function initContent()
    {
        parent::initContent();

        // Get cart id from redirect path (GET parameter 'id').
        $cart_id = (int) Tools::getValue('id');

        // If GET parameter 'id' and current cart id not match - die.
        if ((int) $cart_id != (int) $this->context->cart->id) {
            dump($cart_id . '---' . $this->context->cart->id);
            dump('A problem occured. Ids are not matching');
            die;
        }

        // If cart was not ordered yet.
        if (!$this->context->cart->orderExists()) {
            $customer = new Customer($this->context->cart->id_customer);

            $transaction_id = DB::getInstance()->getRow('SELECT transaction_id FROM ' . _DB_PREFIX_ . IPGCheckout::NAME . '_transactions WHERE cart_id = ' . (int) $this->context->cart->id)['transaction_id'];

            // Get amount form payment status.
            $status = json_decode($this->handler->checkoutStatus($transaction_id), true);

            $amount = $status['approvedAmount']['total'];

            // $amountCurrency = $status['approvedAmount']['currency'];

            // Validate with data
            $this->module->validateOrder(
                (int) $cart_id,
                (int) Configuration::get('PS_OS_PAYMENT'),
                (float) $amount,
                IPGCheckout::PAYMENT_MATHOD_NAME,
                null,
                [
                    'transaction_id' => $transaction_id
                ]
            );

            try {
                DB::getInstance()->delete(IPGCheckout::NAME . '_transactions', 'cart_id = ' . (int) $cart_id);
            } catch (Exception $e) {
                dump($e->getMessage());
                die;
            }
        }

        // Redirect to 'order-confirmation' page.
        Tools::redirect($this->context->link->getPageLink(
            'order-confirmation',
            false,
            (int) $this->context->language->id,
            [
                'id_cart'   => (int) $cart_id,
                'id_module' => (int) $this->module->id,
                'id_order'  => (int) $this->module->currentOrder,
                'key'       => $customer->secure_key,
            ]
        ));
    }
}
