<?php

use GuzzleHttp\Exception\BadResponseException;

require_once dirname(__FILE__) . '/../../vendor/autoload.php';

/**
 * Controller used to generate and redirect to payment link for current cart. Referenced by payment option.
 */
class IPGCheckoutPayModuleFrontController extends ModuleFrontController
{
    /**
     * Prepare payment link for cart and payment methode.
     */
    private function preparePaymentLink(Cart $cart, string $paymentMethode)
    {
        $handler = $this->getCheckoutRequestHandler();
        $result = $handler->createCheckout(
            $this->context->cart,
            $this->context->link->getModuleLink($this->module->name, 'webhook'),
            $this->context->link->getModuleLink($this->module->name, 'success'),
            $this->context->link->getModuleLink($this->module->name, 'payError'),
            $paymentMethode
        );
        $obj = json_decode($result, true);

        return [
            'link'           => $obj['checkout']['redirectionUrl'],
            'transaction_id' => $obj['checkout']['checkoutId']
        ];
    }

    /**
     * Get CheckoutRequestHandler.
     */
    private static function getCheckoutRequestHandler()
    {
        return new CheckoutRequestHandler(
            Configuration::get(IPGCheckout::STORE_ID_KEY),
            Configuration::get(IPGCheckout::API_KEY_KEY),
            Configuration::get(IPGCheckout::SECRET_KEY)
        );
    }

    /**
     * Perform controller.
     */
    public function initContent()
    {
        try {
            parent::initContent();
            // Get payment option provided by request (GET parameter 'option')
            $option = Tools::getValue('option');
            // Delete existing checkout ids for cart id.
            DB::getInstance()->delete(IPGCheckout::NAME . '_transactions', 'cart_id = ' . (int) $this->context->cart->id);
            // Create payment link
            $link = $this->preparePaymentLink($this->context->cart, $option);
            // Insert cart id with checkout id into custom table.
            DB::getInstance()->insert(
                IPGCheckout::NAME . '_transactions',
                [
                    'cart_id'        => (int) $this->context->cart->id,
                    'transaction_id' => pSQL($link['transaction_id'])
                ]
            );
            // Redirect to payment link.
            Tools::redirect($link['link']);
        } catch (BadResponseException $e) {
            if ($e->hasResponse()) {
                PrestaShopLogger::addLog($e->getResponse()->getBody()->getContents(), 3, 0, IPGCheckout::NAME);
            } else {
                PrestaShopLogger::addLog($e->getMessage(), 3, 0, IPGCheckout::NAME);
            }
            Tools::redirect($this->context->link->getModuleLink(IPGCheckout::NAME, 'payError'));
        } catch (Exception $e) {
            PrestaShopLogger::addLog($e->getMessage(), 3, 0, IPGCheckout::NAME);
            Tools::redirect($this->context->link->getModuleLink(IPGCheckout::NAME, 'payError'));
        }
    }
}
