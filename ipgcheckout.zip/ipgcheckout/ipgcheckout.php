<?php

use GuzzleHttp\Exception\ClientException;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/vendor/autoload.php';        

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

/**
 * Entrypoint for PaymentModules in PrestaShop
 */
class IPGCheckout extends PaymentModule
{
    // Name (id) used for this plugin. Reused where needed.
    const NAME = "ipgcheckout";
    // Current version of the plugin. Reused where needed.
    const VERSION = "1.0.2";
    // Key to store the name in Configuration database.
    public const NAME_KEY = "IPG_CHECKOUT_NAME";
    // Default value for store id
    const STORE_ID = "";
    // Key for store id in Configuration database.
    public const STORE_ID_KEY = "IPG_CHECKOUT_STORE_ID";
    // Default value for API Key.
    const API_KEY = "";
    // Key for Api Key in configuration database.
    public const API_KEY_KEY = "IPG_CHECKOUT_API_KEY";
    // Default for secret removed to avoid hardcoded keys in source
    // Key for secret key in configuration database.
    public const SECRET_KEY = "IPG_CHECKOUT_SECRET";
    // Key for sandbox mode in configuration database.
    public const SANDBOX_KEY = "IPG_CHECKOUT_SANDBOX";
    // Default value for sandbox mode.
    const SANDBOX = true;
    // Default name of this plugin (for display).
    public const PAYMENT_MATHOD_NAME = "IPG Checkout";
    // Key to store visibility for generic checkout.
    public const GENERIC_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_GENERIC_CHECKOUT_ACTIVE";
    // Key to store visibility for debit checkout.
    public const DEBIT_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_DEBIT_CHECKOUT_ACTIVE";
    // Key to store visibility for Apple Pay.
    public const APPLE_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_APPLE_CHECKOUT_ACTIVE";
    // Key to store visibility for Google Pay.
    public const GOOGLE_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_GOOGLE_CHECKOUT_ACTIVE";
    // Key to store visibility for Bizum.
    public const BIZUM_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_BIZUM_ACTIVE";
    // Key to store visibility for iDeal.
    public const IDEAL_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_IDEAL_ACTIVE";
    // String value for true
    public const TRUE = 'TRUE';
    // String value for false
    public const FALSE = 'FALSE';

    /**
     * Default setup with informations. Should correlate to config.xml.
     */
    public function __construct()
    {
        $this->name = IPGCheckout::NAME;
        $this->tab = 'payments_gateways';
        $this->version = IPGCheckout::VERSION;
        $this->author = 'Fiserv';
        $this->need_instance = 1;
        $this->is_configurable = 1;

        parent::__construct();

        $this->displayName = $this->trans('IPG Checkout', [], 'Modules.Ipgcheckout.Admin');
        $this->description = $this->trans('IPG Checkout by Fiserv', [], 'Modules.Ipgcheckout.Admin');
    }

    /**
     * Form to be displayed for configuration.
     */
    public function displayForm()
    {
        $form = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Settings', [], 'Modules.Ipgcheckout.Admin'),
                ],
                'input' => [
                    // Inputs about sandbox mode.
                    [
                        'type' => 'select',
                        'label' => $this->trans('Mode', [], 'Modules.Ipgcheckout.Admin'),
                        'desc' => $this->trans('Use Live (Production) Mode or Test (Sandbox) Mode', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::SANDBOX_KEY,
                        'required' => true,
                        'options' => array(
                            'query' => [
                                [
                                    'id_option' => 'TRUE',
                                    'name' => $this->trans('Sandbox', [], 'Modules.Ipgcheckout.Admin')
                                ],
                                [
                                    'id_option' => 'FALSE',
                                    'name' => $this->trans('Live', [], 'Modules.Ipgcheckout.Admin')
                                ],
                            ],
                            'id' => 'id_option',
                            'name' => 'name'
                        )
                    ],
                    // Inputs about store id.
                    [
                        'type' => 'text',
                        'label' => $this->trans('Store ID', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::STORE_ID_KEY,
                        'size' => 20,
                        'required' => true
                    ],
                    // Inputs about API Key.
                    [
                        'type' => 'text',
                        'label' => $this->trans('API Key', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::API_KEY_KEY,
                        'size' => 20,
                        'required' => true
                    ],
                    // Inputs about secret.
                    [
                        'type' => 'text',
                        'label' => $this->trans('API Secret', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::SECRET_KEY,
                        'size' => 20,
                        'required' => true,                     
                        'class' => 'masked'
                    ],
                    $this->buildToggleSelectField($this->trans('Generic Checkout', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Credit / Debit Card', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Apple Pay', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Google Pay', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Bizum', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('iDEAL | Wero', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY)
                ],
                // Submit Button
                'submit' => [
                    'title' => $this->trans('Save', [], 'Modules.Ipgcheckout.Admin'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false, [], ['configure' => $this->name]);
        $helper->submit_action = 'submit' . $this->name;

        // Default language
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');

        // Load current value into the form
        $helper->fields_value[IPGCheckout::STORE_ID_KEY] = Tools::getValue(IPGCheckout::STORE_ID_KEY, Configuration::get(IPGCheckout::STORE_ID_KEY));
        $helper->fields_value[IPGCheckout::API_KEY_KEY] = Tools::getValue(IPGCheckout::API_KEY_KEY, Configuration::get(IPGCheckout::API_KEY_KEY));
        $helper->fields_value[IPGCheckout::SECRET_KEY] = Tools::getValue(IPGCheckout::SECRET_KEY, Configuration::get(IPGCheckout::SECRET_KEY));
        $helper->fields_value[IPGCheckout::SANDBOX_KEY] = Tools::getValue(IPGCheckout::SANDBOX_KEY, Configuration::get(IPGCheckout::SANDBOX_KEY));

        $toggleKeys = [
            IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY,
        ];

        foreach ($toggleKeys as $key) {
            $helper->fields_value[$key] = Tools::getValue($key, Configuration::get($key));
        }

        return $helper->generateForm([$form]);
    }

    /**
     * Method called for configration page.
     */
    public function getContent()
    {
        // Set output to empty string.
        $output = '';

        // Only call stuff if form is submitted (after clicking "Save" button). Not performed by clicking on "Configure"
        if (Tools::isSubmit('submit' . $this->name)) {
            // Load data to be saved from request
            $storeId = (string) Tools::getValue(IPGCheckout::STORE_ID_KEY);
            $apiKey = (string) Tools::getValue(IPGCheckout::API_KEY_KEY);
            $secret = (string) Tools::getValue(IPGCheckout::SECRET_KEY);
            $sandbox = (string) Tools::getValue(IPGCheckout::SANDBOX_KEY);

            $genericCheckout = (string) Tools::getValue(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY);
            $debitCheckout = (string) Tools::getValue(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY);
            $appleCheckout = (string) Tools::getValue(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY);
            $googleCheckout = (string) Tools::getValue(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY);
            $bizumCheckout = (string) Tools::getValue(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY);
            $idealCheckout = (string) Tools::getValue(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY);

            // TODO: Check if this is needed anymore
            $this->displayError($this->trans('Invalid Configuration value', [], 'Modules.Ipgcheckout.Admin'));

            // Display error any field value is wrong else proceed.
            if (empty($storeId) || empty($apiKey) || empty($secret) || empty($sandbox) || empty($genericCheckout) || empty($debitCheckout) || empty($appleCheckout) || empty($googleCheckout) || empty($bizumCheckout) || empty($idealCheckout)) {
                $output = $this->displayError($this->trans('Invalid Configuration value', [], 'Modules.Ipgcheckout.Admin'));
            } else {
                // Update data with data submitted
                Configuration::updateValue(IPGCheckout::STORE_ID_KEY, trim($storeId));
                Configuration::updateValue(IPGCheckout::API_KEY_KEY, trim($apiKey));
                Configuration::updateValue(IPGCheckout::SECRET_KEY, trim($secret));
                Configuration::updateValue(IPGCheckout::SANDBOX_KEY, $sandbox);

                Configuration::updateValue(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY, $genericCheckout);
                Configuration::updateValue(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY, $debitCheckout);
                Configuration::updateValue(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY, $appleCheckout);
                Configuration::updateValue(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY, $googleCheckout);
                Configuration::updateValue(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY, $bizumCheckout);
                Configuration::updateValue(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY, $idealCheckout);
                
                // Output that settings have been changed
                $output = $this->displayConfirmation($this->trans('Settings updated', [], 'Modules.Ipgcheckout.Admin'));

                // Check if configuration (only API Key and Secret are tested) are accepted by Checkout API.
                if (!$this->validateCredentials($sandbox, $storeId, $apiKey, $secret)) {
                    $output .= $this->displayError($this->trans('Payment method failed. Please check on settings page if API credentials are set correctly.', [], 'Modules.Ipgcheckout.Admin'));
                }
            }
        }

        // Build form and return it.
        return $output . '<div>
            <div style="margin-top: 5px; margin-bottom: 15px"><img src="' . Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/fiserv-logo.svg') . '" /></div>
            <p>' . $this->trans('Pay securely with Fiserv Checkout. Acquire API credentials on our portal.', [], 'Modules.Ipgcheckout.Admin') . '</p>
            <p> <a href="' . $this->trans('https://docs.fiserv.dev/public/docs/guides', [], 'Modules.Ipgcheckout.Admin') . '" target="_blank">' . $this->trans('Visit Fiserv developer guide', [], 'Modules.Ipgcheckout.Admin') . '</a><p/>
        </div>' . $this->displayForm();
    }

    /**
     * Validate credential wrapper.
     */
    private function validateCredentials(string $sandbox, string $storeId, string $apiKey, string $secret): bool
    {
        return ValidateRequest::getInstance()->validateCredentials();
    }

    /**
     * Hook provides payment option and redirected offered by plugin.
     */
    public function hookPaymentOptions($params)
    {
        // Skip is plugin isn't active.
        if (!$this->active) {
            return;
        }

        // Create empty array to provide payment options active.
        $paymentOptions = [];

        // Add Generic Checkout as payment options if active.
        if (Configuration::get(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            // create a PaymentOption of type Offline
            $genericOption = new PaymentOption();
            $genericOption->setModuleName($this->name);
            $genericOption->setCallToActionText($this->trans('Generic Checkout', [], 'Modules.Ipgcheckout.Front'));
            $genericOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "generic"]));
            $genericOption->setAdditionalInformation($this->additionalInformationGeneric());
            //$genericOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-gateway-generic.svg'));
            $paymentOptions[] = $genericOption;
        }

        // Add Debit Checkout as payment options if active.
        if (Configuration::get(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $debitOption = new PaymentOption();
            $debitOption->setModuleName($this->name);
            $debitOption->setCallToActionText($this->trans('Credit / Debit Card', [], 'Modules.Ipgcheckout.Front'));
            $debitOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "cards"]));
            $debitOption->setAdditionalInformation($this->additionalInformation());
            //$debitOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-credit-card.svg'));
            $paymentOptions[] = $debitOption;
        }

        // Add Apple Pay as payment options if active.
        if (Configuration::get(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $appleOption = new PaymentOption();
            $appleOption->setModuleName($this->name);
            $appleOption->setCallToActionText($this->trans('Apple Pay', [], 'Modules.Ipgcheckout.Front'));
            $appleOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "applepay"]));
            $appleOption->setAdditionalInformation($this->additionalInformation());
            //$appleOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-apple-pay.svg'));
            $paymentOptions[] = $appleOption;
        }

        // Add Google Pay as payment options if active.
        if (Configuration::get(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $googleOption = new PaymentOption();
            $googleOption->setModuleName($this->name);
            $googleOption->setCallToActionText($this->trans('Google Pay', [], 'Modules.Ipgcheckout.Front'));
            $googleOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "googlepay"]));
            $googleOption->setAdditionalInformation($this->additionalInformation());
            //$googleOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-google-pay.svg'));
            $paymentOptions[] = $googleOption;
        }

        // Add Bizum as payment options if active.
        if (Configuration::get(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $bizumOption = new PaymentOption();
            $bizumOption->setModuleName($this->name);
            $bizumOption->setCallToActionText($this->trans('Bizum', [], 'Modules.Ipgcheckout.Front'));
            $bizumOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "bizum"]));
            $bizumOption->setAdditionalInformation($this->additionalInformation());
            //$bizumOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-bizum-pay.png'));
            $paymentOptions[] = $bizumOption;
        }

        // Add iDeal as payment options if active.
        if (Configuration::get(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $idealOption = new PaymentOption();
            $idealOption->setModuleName($this->name);
            $idealOption->setCallToActionText($this->trans('iDEAL | Wero', [], 'Modules.Ipgcheckout.Front'));
            $idealOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "ideal"]));
            $idealOption->setAdditionalInformation($this->additionalInformation());
            //$idealOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-ideal-pay.png'));
            $paymentOptions[] = $idealOption;
        }

        // Return array with payment options active.
        return $paymentOptions;
    }

    /**
     * Additional information used for payment options.
     */
    private function additionalInformation()
    {
        return '<p>' . $this->trans('You will be redirected to an external checkout page.', [], 'Modules.Ipgcheckout.Front') . '</p>';
    }

    /**
     * Additional information used for Generic Checkout
     */
    private function additionalInformationGeneric()
    {
        return '<p>' . $this->trans('You will be redirected to an external checkout page where you will be able to select the other payment methods.', [], 'Modules.Ipgcheckout.Front') . '</p>';
    }

    /**
     * Active new translation system of PrestaShop.
     */
    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    /**
     * Created the custom helper table for storing cart id with corrensponding checkout id (IPG).
     */
    public function createTable()
    {
        DB::getInstance()->execute('CREATE TABLE ' . _DB_PREFIX_ . IPGCheckout::NAME . '_transactions (cart_id INT(11) NOT NULL, transaction_id VARCHAR(255) NOT NULL) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;');
        return true;
    }

    /**
     * Drop the custom helper table.
     */
    public function dropTable()
    {
        DB::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . IPGCheckout::NAME . '_transactions;');
        return true;
    }

    /**
     * Executed when a refund with order slip is executed. Used for refunds. "Order Slip" must be checked.
     */
    public function hookActionOrderSlipAdd($params)
    {
        // Get order id.
        $order = new Order($params['order']->id);
        // Get order slip id created.
        $orderSlip = new OrderSlip($params['orderSlipCreated']->id);
        // Calculate amount to be refunded.
        $amount = $orderSlip->amount + $orderSlip->shipping_cost_amount;

        // Skip refund if order has no payments.
        if (count($order->getOrderPayments()) <= 0) {
            return;
        }

        // Skip refund if payment method doesn't match IPG.
        if ($order->getOrderPayments()[0]) {
            $payment = new OrderPayment($order->getOrderPayments()[0]->id);
            if ($payment->payment_method !== IPGCheckout::PAYMENT_MATHOD_NAME) {
                return;
            }
        }

        try {
            // Get checkout id.
            $checkout_id = $order->getOrderPayments()[0]->transaction_id;
            // Get transaction id.
            $transaction_id = CheckoutRequestHandler::getInstance()->getTransactionId($checkout_id);
            // Performe refund on IPG.
            $refundedResponse = json_decode(RefundRequestHandler::getInstance()->request($order, $transaction_id, $amount), true);
            // Get refunded amount.
            $refundedAmount = $refundedResponse['transactionAmount']['total'];
            // Get refunded currency.
            $refundedCurrency = $refundedResponse['transactionAmount']['currency'];
            // Create message if refund was performed.
            RefundRequestHandler::writeMessage($order, "Refunded " . $refundedAmount . ' ' . $refundedCurrency . ' for Credit Slip Number ' . $orderSlip->id .' (Gateway Transaction ID: '.$transaction_id.')');
        } catch (ClientException $e) {
            PrestaShopLogger::addLog('Order (' . $order->id . ') slip total amount (calculated): ' . $amount, 1, 0, IPGCheckout::NAME, $order->id);
            PrestaShopLogger::addLog('Order (' . $order->id . ') slip amount (provided by PrestaShop): ' . $orderSlip->amount, 1, 0, IPGCheckout::NAME, $order->id);
            PrestaShopLogger::addLog('Order (' . $order->id . ') slip shipping cost amount (provided by PrestaShop): ' . $orderSlip->shipping_cost_amount, 1, 0, IPGCheckout::NAME, $order->id);
            PrestaShopLogger::addLog(var_export($e->getMessage(), true), 3, 0, IPGCheckout::NAME);
            RefundRequestHandler::writeMessage($order, "Refunding failed: " . $amount);
            // Because refund faild remove credit slip.
            $orderSlip->delete();
            // Session set to display error if refund fails. Used in hookDisplayAdminOrderTop.
            $_SESSION['hook_order_slip_error'] = 'Refund failed';
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Order (' . $order->id . ') slip total amount (calculated): ' . $amount, 1, 0, IPGCheckout::NAME, $order->id);
            PrestaShopLogger::addLog('Order (' . $order->id . ') slip amount (provided by PrestaShop): ' . $orderSlip->amount, 1, 0, IPGCheckout::NAME, $order->id);
            PrestaShopLogger::addLog('Order (' . $order->id . ') slip shipping cost amount (provided by PrestaShop): ' . $orderSlip->shipping_cost_amount, 1, 0, IPGCheckout::NAME, $order->id);
            PrestaShopLogger::addLog(var_export($e, true), 3, 0, IPGCheckout::NAME);
            RefundRequestHandler::writeMessage($order, "Refunding failed: " . $amount);
            // Because refund faild remove credit slip.
            $orderSlip->delete();
            // Session set to display error if refund fails. Used in hookDisplayAdminOrderTop.
            $_SESSION['hook_order_slip_error'] = 'Refund failed';
        }
    }

    /**
     * Looking for 'hook_order_slip_error' in session. If is presend show error message.
     */
    public function hookDisplayAdminOrderTop($params)
    {
        if (isset($_SESSION['hook_order_slip_error'])) {
            unset($_SESSION['hook_order_slip_error']);
            return $this->displayError($this->trans("Refund failed! Created Credit Slip was removed. Manual treatment mighty be necessary!", [], 'Modules.Ipgcheckout.Admin'));
        }
    }
    
    /**
     * Added css
     */
    public function hookDisplayBackOfficeHeader($params)
    {
        if (Tools::getValue('configure') === $this->name) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
        }
    }

    /**
     * Display transaction detail.
     */
    public function hookDisplayAdminOrderSideBottom($params)
    {
        // Get order id.
        $order = new Order($params['id_order']);
        // Skip if order has no payments.
        if (count($order->getOrderPayments()) <= 0) {
            return;
        }
        // Skip if order has no matching payment to IPG.
        if ($order->getOrderPayments()[0]) {
            $payment = new OrderPayment($order->getOrderPayments()[0]->id);
            if ($payment->payment_method !== IPGCheckout::PAYMENT_MATHOD_NAME) {
                return;
            }
        }
        // Get checkout id.
        $checkout_id = $order->getOrderPayments()[0]->transaction_id;
        // Request current status.
        $response = CheckoutRequestHandler::getInstance()->checkoutStatus($checkout_id);
        // Decode current status.
        $status = json_decode($response, true);
        // Preparte data for template.
        $this->context->smarty->assign([
            'checkout_id' => $checkout_id,
            'trace_id' => $status['ipgTransactionDetails']['apiTraceId'],
            'paymentMethodType' => $status['paymentMethodUsed']['paymentMethodType'],
            'status' => $status,
            'response' => $response
        ]);
        // Return response of template.
        return $this->display(__FILE__, 'views/templates/admin/orderSide.tpl');
    }

    protected function buildToggleSelectField(string $label, string $name, bool $required = true): array
    {
        return [
            'type'     => 'select',
            'label'    => $label,
            'name'     => $name,
            'required' => $required,
            'options'  => [
                'query' => [
                    [
                        'id_option' => 'TRUE',
                        'name'      => $this->trans('Active', [], 'Modules.Ipgcheckout.Admin'),
                    ],
                    [
                        'id_option' => 'FALSE',
                        'name'      => $this->trans('Deactivated', [], 'Modules.Ipgcheckout.Admin'),
                    ],
                ],
                'id'   => 'id_option',
                'name' => 'name',
            ],
        ];
    }


    /**
     * Performed on installing plugin. Not on updating
     */
    public function install()
    {
        return (
            parent::install()
            // Create custom table
            && $this->createTable()
            // Register hooks
            && $this->registerHook('paymentOptions')
            && $this->registerHook('actionOrderSlipAdd')
            && $this->registerHook('displayAdminOrderSideBottom')
            && $this->registerHook('displayAdminOrderTop')
            && $this->registerHook('displayBackOfficeHeader')
            // Set default configurations
            && Configuration::updateValue(IPGCheckout::NAME_KEY, IPGCheckout::NAME)
            && Configuration::updateValue(IPGCheckout::STORE_ID_KEY, IPGCheckout::STORE_ID)
            && Configuration::updateValue(IPGCheckout::API_KEY_KEY, IPGCheckout::API_KEY)
            && Configuration::updateValue(IPGCheckout::SANDBOX_KEY, IPGCheckout::SANDBOX)
            && Configuration::updateValue(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY, IPGCheckout::FALSE)
            && Configuration::updateValue(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY, IPGCheckout::FALSE)
        );
    }

    /**
     * Performed of deleting plugin.
     */
    public function uninstall()
    {
        return (
            parent::uninstall()
            // Drop custom table.
            && $this->dropTable()
            // Unregister hooks.
            && $this->unregisterHook('paymentOptions')
            && $this->unregisterHook('actionOrderSlipAdd')
            && $this->unregisterHook('displayAdminOrderSideBottom')
            && $this->unregisterHook('displayAdminOrderTop')
            && $this->unregisterHook('displayBackOfficeHeader')
            // Delete configurations.
            && Configuration::deleteByName(IPGCheckout::NAME_KEY)
            && Configuration::deleteByName(IPGCheckout::STORE_ID_KEY)
            && Configuration::deleteByName(IPGCheckout::API_KEY_KEY)
            && Configuration::deleteByName(IPGCheckout::SECRET_KEY)
            && Configuration::deleteByName(IPGCheckout::SANDBOX_KEY)
            && Configuration::deleteByName(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY)
        );
    }
}