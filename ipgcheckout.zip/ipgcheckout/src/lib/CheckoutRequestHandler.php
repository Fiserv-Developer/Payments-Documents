<?php

require_once dirname(__FILE__) . '/../../vendor/autoload.php';
class CheckoutRequestHandler extends RequestHandler
{
    public const SHOPPLUGIN_HEADER_FIELD = 'x-shopplugin'; 
    public const HEADER_X_SHOPPLUGIN = 'fiserv_prestashop_'.IPGCheckout::VERSION;
    public const HEADER_USER_AGENT = 'ShoppingCartPlugin/'.IPGCheckout::VERSION.' (prestashop/'._PS_VERSION_.'; ClientLib/FiservPhpClient-NONE; PHP/'.PHP_VERSION.')';

    /**
     * Create a new instance of CheckoutRequestHandler with environment configuration
     */
    public static function getInstance(): CheckoutRequestHandler
    {
        return new CheckoutRequestHandler(
            Configuration::get(IPGCheckout::STORE_ID_KEY),
            Configuration::get(IPGCheckout::API_KEY_KEY),
            Configuration::get(IPGCheckout::SECRET_KEY)
        );
    }

    /**
     * Get Uri depending on sandbox mode.
     */
    protected function getCheckoutUri()
    {
        if (Configuration::get(IPGCheckout::SANDBOX_KEY) === 'FALSE') {
            return 'https://prod.emea.api.fiservapps.com/exp/v1/checkouts';
        }

        return 'https://prod.emea.api.fiservapps.com/sandbox/exp/v1/checkouts';
    }

    private function toPaymentMethod($name)
    {
        $allowed = ['applepay', 'googlepay', 'cards', 'bizum', 'ideal'];
        $name = trim($name);

        return in_array($name, $allowed, true) ? $name : 'generic';
    }

    /**
     * Prepare body to be send to API.
     */
    private function prepareCreateCheckoutRequestBody(Cart $cart, string $webHooksUrl, string $successUrl, string $failureUrl, string $paymentMethode): string
    {
        ini_set('serialize_precision', -1); // if not there is a float error at some numbers
        $total = $cart->getCartTotalPrice();
        $total_items = $cart->getOrderTotal(true, Cart::ONLY_PRODUCTS) - $cart->getOrderTotal(true, Cart::ONLY_DISCOUNTS);
        $vat_amaount = $cart->getOrderTotal(true) - $cart->getOrderTotal(false);
        $shipping_costs = $cart->getTotalShippingCost();

        if ($vat_amaount > 0) {
            $total_items -= $vat_amaount;
        }

        $currency = (new Currency((int) $cart->id_currency))->iso_code;
        $customer = new Customer((int) $cart->id_customer);
        $address = new Address((int) $cart->id_address_invoice);
        $language = new Language((int) $cart->id_lang);
        $formatted_locale = str_replace('-', '_', $language->locale);

        $obj = [
            'storeId'           => $this->storeId,
            'transactionOrigin' => 'ECOM',
            'transactionType'   => 'SALE',
            'order'             => [
                'basket' => [
                    'lineItems' => array_map(function ($product) {
                        return [
                            'itemIdentifier' => (string) $product['id_product'],
                            'name'           => $product['name'],
                            'price'          => $product['price'],
                            'quantity'       => $product['quantity'],
                            'total'          => $product['total']
                        ];
                    }, $cart->getProducts())
                ],
                'billing' => [
                    'person' => [
                        'firstName' => $customer->firstname,
                        'lastName'  => $customer->lastname
                    ],
                    'contact' => [
                        'email' => $customer->email
                    ],
                    'address' => [
                        'address1'   => $address->address1,
                        'address2'   => $address->address2,
                        'city'       => $address->city,
                        'country'    => Country::getIsoById((int) $address->id_country),
                        'postalCode' => $address->postcode
                    ]
                ]
            ],
            'transactionAmount' => [
                'total'      => $total,
                'currency'   => $currency,
                'components' => [
                    'subtotal'  => round($total_items, 2),
                    'shipping'  => round($shipping_costs, 2),
                    'vatAmount' => round($vat_amaount, 2)
                ]
            ],
            'checkoutSettings' => [
                'locale'                   => $formatted_locale,
                'preSelectedPaymentMethod' => $paymentMethode == 'generic' ? null : $paymentMethode,
                'webHooksUrl'              => $webHooksUrl . '?id=' . $cart->id,
                'redirectBackUrls'         => [
                    'successUrl' => $successUrl . '?id=' . $cart->id,
                    'failureUrl' => $failureUrl . '?id=' . $cart->id
                ]
            ]
        ];

        $json = json_encode($obj);

        return $json;
    }

    /**
     * Create checkout link and id. Set headers.
     */
    public function createCheckout(Cart $cart, string $webHooksUrl, string $successUrl, string $failureUrl, string $paymentMethode)
    {
        $time = (int) (microtime(true) * 1000);
        $clientRequestId = CheckoutRequestHandler::generateUuid();
        $requestBody = $this->prepareCreateCheckoutRequestBody($cart, $webHooksUrl, $successUrl, $failureUrl, $this->toPaymentMethod($paymentMethode));
        $messageSignature = $this->sign($clientRequestId, $time, $requestBody);
        $client = new \GuzzleHttp\Client();
        $requestOptions = [
            'body'    => $requestBody,
            'headers' => [
                'accept'                                        => 'application/json',
                'content-type'                                  => 'application/json',
                'Api-Key'                                       => $this->apiKey,
                'Client-Request-Id'                             => $clientRequestId,
                'Message-Signature'                             => $messageSignature,
                'Timestamp'                                     => $time,
                'User-Agent'                                    => CheckoutRequestHandler::HEADER_USER_AGENT,
                CheckoutRequestHandler::SHOPPLUGIN_HEADER_FIELD => CheckoutRequestHandler::HEADER_X_SHOPPLUGIN
            ],
        ];
        $response = $client->request('POST', $this->getCheckoutUri(), $requestOptions);

        return $response->getBody()->getContents();
    }

    /**
     * Request checkout status.
     */
    public function checkoutStatus(string $checkoutId)
    {
        $time = (int) (microtime(true) * 1000);
        $clientRequestId = CheckoutRequestHandler::generateUuid();
        $messageSignature = $this->sign($clientRequestId, $time);
        $client = new \GuzzleHttp\Client();
        $response = $client->request('GET', $this->getCheckoutUri() . '/' . $checkoutId, [
            'headers' => [
                'accept'                                        => 'application/json',
                'content-type'                                  => 'application/json',
                'Api-Key'                                       => $this->apiKey,
                'Client-Request-Id'                             => $clientRequestId,
                'Message-Signature'                             => $messageSignature,
                'Timestamp'                                     => $time,
                'User-Agent'                                    => CheckoutRequestHandler::HEADER_USER_AGENT,
                CheckoutRequestHandler::SHOPPLUGIN_HEADER_FIELD => CheckoutRequestHandler::HEADER_X_SHOPPLUGIN
            ],
        ]);

        return $response->getBody()->getContents();
    }

    /**
     * Retrieve IPG transaction id.
     */
    public function getTransactionId($checkoutId)
    {
        $status = json_decode(CheckoutRequestHandler::getInstance()->checkoutStatus($checkoutId), true);

        return $status['ipgTransactionDetails']['ipgTransactionId'];
    }
}
