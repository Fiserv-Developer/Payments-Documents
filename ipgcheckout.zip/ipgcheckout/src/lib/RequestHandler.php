<?php

/**
 * Abstract RequestHandler providing methodes for authentication and encryption for IPG Apis.
 */
abstract class RequestHandler
{
    /**
     * Provide Configuration
     */
    public function __construct(protected string $storeId, protected string $apiKey, protected string $secret)
    {
    }

    // Contains the URL to be used.
    abstract protected function getCheckoutUri();

    // Signing methode for IPG Apis.
    protected function sign(string $requestId, int $time, string $body = '')
    {
        $token = $this->apiKey . $requestId . $time . $body;

        return base64_encode(hash_hmac('sha256', $token, (string) ($this->secret), true));
    }

    // Simple Uuid generater. Not depending on other libraries or frameworks.
    protected static function generateUuid(): string
    {
        $out = bin2hex(random_bytes(18));

        $out[8] = '-';
        $out[13] = '-';
        $out[18] = '-';
        $out[23] = '-';
        $out[14] = '4';
        $out[19] = ['8', '9', 'a', 'b'][random_int(0, 3)];

        return $out;
    }
}
