<?php

use GuzzleHttp\Exception\ClientException;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/vendor/autoload.php';

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

/**
 * Entrypoint for PaymentModules in PrestaShop
 */
class IPGCheckout extends PaymentModule
{
    // Name (id) used for this plugin. Reused where needed.
    const NAME = "ipgcheckout";
    // Current version of the plugin. Reused where needed.
    const VERSION = "1.1.0";
    // Key to store the name in Configuration database.
    const NAME_KEY = "IPG_CHECKOUT_NAME";
    // Default value for store id
    const STORE_ID = "";
    // Key for store id in Configuration database.
    const STORE_ID_KEY = "IPG_CHECKOUT_STORE_ID";
    // Default value for API Key.
    const API_KEY = "";
    // Key for Api Key in configuration database.
    const API_KEY_KEY = "IPG_CHECKOUT_API_KEY";
    // Default for secret removed to avoid hardcoded keys in source
    // Key for secret key in configuration database.
    const SECRET_KEY = "IPG_CHECKOUT_SECRET";
    // Key for sandbox mode in configuration database.
    const SANDBOX_KEY = "IPG_CHECKOUT_SANDBOX";
    // Default value for sandbox mode.
    const SANDBOX = true;
    // Default name of this plugin (for display).
    const PAYMENT_MATHOD_NAME = "IPG Checkout";
    // Key to store visibility for generic checkout.
    const GENERIC_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_GENERIC_CHECKOUT_ACTIVE";
    // Key to store visibility for debit checkout.
    const DEBIT_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_DEBIT_CHECKOUT_ACTIVE";
    // Key to store visibility for Apple Pay.
    const APPLE_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_APPLE_CHECKOUT_ACTIVE";
    // Key to store visibility for Google Pay.
    const GOOGLE_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_GOOGLE_CHECKOUT_ACTIVE";
    // Key to store visibility for Bizum.
    const BIZUM_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_BIZUM_ACTIVE";
    // Key to store visibility for iDeal.
    const IDEAL_CHECKOUT_ACTIVE_KEY = "IPG_CHECKOUT_IDEAL_ACTIVE";
    // String value for true
    const TRUE = 'TRUE';
    // String value for false
    const FALSE = 'FALSE';

    /**
     * Default setup with informations. Should correlate to config.xml.
     */
    public function __construct()
    {
        $this->name = IPGCheckout::NAME;
        $this->tab = 'payments_gateways';
        $this->version = IPGCheckout::VERSION;
        $this->author = 'Fiserv';
        $this->need_instance = 1;
        $this->is_configurable = 1;

        parent::__construct();

        $this->displayName = $this->trans('IPG Checkout', [], 'Modules.Ipgcheckout.Admin');
        $this->description = $this->trans('IPG Checkout by Fiserv', [], 'Modules.Ipgcheckout.Admin');
    }

    /**
     * Form to be displayed for configuration.
     */
    public function displayForm()
    {
        $form = [
            'form' => [
                'legend' => [
                    'title' => $this->trans('Settings', [], 'Modules.Ipgcheckout.Admin'),
                ],
                'input' => [
                    // Inputs about sandbox mode.
                    [
                        'type' => 'select',
                        'label' => $this->trans('Mode', [], 'Modules.Ipgcheckout.Admin'),
                        'desc' => $this->trans('Use Live (Production) Mode or Test (Sandbox) Mode', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::SANDBOX_KEY,
                        'required' => true,
                        'options' => array(
                            'query' => [
                                [
                                    'id_option' => 'TRUE',
                                    'name' => $this->trans('Sandbox', [], 'Modules.Ipgcheckout.Admin')
                                ],
                                [
                                    'id_option' => 'FALSE',
                                    'name' => $this->trans('Live', [], 'Modules.Ipgcheckout.Admin')
                                ],
                            ],
                            'id' => 'id_option',
                            'name' => 'name'
                        )
                    ],
                    // Inputs about store id.
                    [
                        'type' => 'text',
                        'label' => $this->trans('Store ID', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::STORE_ID_KEY,
                        'size' => 20,
                        'required' => true
                    ],
                    // Inputs about API Key.
                    [
                        'type' => 'text',
                        'label' => $this->trans('API Key', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::API_KEY_KEY,
                        'size' => 20,
                        'required' => true
                    ],
                    // Inputs about secret.
                    [
                        'type' => 'text',
                        'label' => $this->trans('API Secret', [], 'Modules.Ipgcheckout.Admin'),
                        'name' => IPGCheckout::SECRET_KEY,
                        'size' => 20,
                        'required' => true,
                        'class' => 'masked'
                    ],
                    $this->buildToggleSelectField($this->trans('Generic Checkout', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Credit / Debit Card', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Apple Pay', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Google Pay', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('Bizum', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY),
                    $this->buildToggleSelectField($this->trans('iDEAL | Wero', [], 'Modules.Ipgcheckout.Admin'), IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY)
                ],
                // Submit Button
                'submit' => [
                    'title' => $this->trans('Save', [], 'Modules.Ipgcheckout.Admin'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->table = $this->table;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false, [], ['configure' => $this->name]);
        $helper->submit_action = 'submit' . $this->name;

        // Default language
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');

        // Load current value into the form
        $helper->fields_value[IPGCheckout::STORE_ID_KEY] = Tools::getValue(IPGCheckout::STORE_ID_KEY, Configuration::get(IPGCheckout::STORE_ID_KEY));
        $helper->fields_value[IPGCheckout::API_KEY_KEY] = Tools::getValue(IPGCheckout::API_KEY_KEY, Configuration::get(IPGCheckout::API_KEY_KEY));
        $helper->fields_value[IPGCheckout::SECRET_KEY] = Tools::getValue(IPGCheckout::SECRET_KEY, Configuration::get(IPGCheckout::SECRET_KEY));
        $helper->fields_value[IPGCheckout::SANDBOX_KEY] = Tools::getValue(IPGCheckout::SANDBOX_KEY, Configuration::get(IPGCheckout::SANDBOX_KEY));

        $toggleKeys = [
            IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY,
            IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY,
        ];

        foreach ($toggleKeys as $key) {
            $helper->fields_value[$key] = Tools::getValue($key, Configuration::get($key));
        }

        return $helper->generateForm([$form]);
    }

    /**
     * Method called for configration page.
     */
    public function getContent()
    {
        // Set output to empty string.
        $output = '';

        // Only call stuff if form is submitted (after clicking "Save" button). Not performed by clicking on "Configure"
        if (Tools::isSubmit('submit' . $this->name)) {
            // Load data to be saved from request
            $storeId = (string) Tools::getValue(IPGCheckout::STORE_ID_KEY);
            $apiKey = (string) Tools::getValue(IPGCheckout::API_KEY_KEY);
            $secret = (string) Tools::getValue(IPGCheckout::SECRET_KEY);
            $sandbox = (string) Tools::getValue(IPGCheckout::SANDBOX_KEY);

            $genericCheckout = (string) Tools::getValue(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY);
            $debitCheckout = (string) Tools::getValue(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY);
            $appleCheckout = (string) Tools::getValue(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY);
            $googleCheckout = (string) Tools::getValue(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY);
            $bizumCheckout = (string) Tools::getValue(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY);
            $idealCheckout = (string) Tools::getValue(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY);

            // TODO: Check if this is needed anymore
            $this->displayError($this->trans('Invalid Configuration value', [], 'Modules.Ipgcheckout.Admin'));

            // Display error any field value is wrong else proceed.
            if (empty($storeId) || empty($apiKey) || empty($secret) || empty($sandbox) || empty($genericCheckout) || empty($debitCheckout) || empty($appleCheckout) || empty($googleCheckout) || empty($bizumCheckout) || empty($idealCheckout)) {
                $output = $this->displayError($this->trans('Invalid Configuration value', [], 'Modules.Ipgcheckout.Admin'));
            } else {
                // Update data with data submitted
                Configuration::updateValue(IPGCheckout::STORE_ID_KEY, trim($storeId));
                Configuration::updateValue(IPGCheckout::API_KEY_KEY, trim($apiKey));
                Configuration::updateValue(IPGCheckout::SECRET_KEY, trim($secret));
                Configuration::updateValue(IPGCheckout::SANDBOX_KEY, $sandbox);

                Configuration::updateValue(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY, $genericCheckout);
                Configuration::updateValue(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY, $debitCheckout);
                Configuration::updateValue(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY, $appleCheckout);
                Configuration::updateValue(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY, $googleCheckout);
                Configuration::updateValue(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY, $bizumCheckout);
                Configuration::updateValue(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY, $idealCheckout);

                // Output that settings have been changed
                $output = $this->displayConfirmation($this->trans('Settings updated', [], 'Modules.Ipgcheckout.Admin'));

                // Check if configuration (only API Key and Secret are tested) are accepted by Checkout API.
                if (!$this->validateCredentials($sandbox, $storeId, $apiKey, $secret)) {
                    $output .= $this->displayError($this->trans('Payment method failed. Please check on settings page if API credentials are set correctly.', [], 'Modules.Ipgcheckout.Admin'));
                }
            }
        }

        // Build form and return it.
        return $output . '<div>
            <div style="margin-top: 5px; margin-bottom: 15px"><img src="' . Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/fiserv-logo.svg') . '" /></div>
            <p>' . $this->trans('Pay securely with Fiserv Checkout. Acquire API credentials on our portal.', [], 'Modules.Ipgcheckout.Admin') . '</p>
            <p> <a href="' . $this->trans('https://docs.fiserv.dev/public/docs/guides', [], 'Modules.Ipgcheckout.Admin') . '" target="_blank">' . $this->trans('Visit Fiserv developer guide', [], 'Modules.Ipgcheckout.Admin') . '</a><p/>
        </div>' . $this->displayForm();
    }

    /**
     * Validate credential wrapper.
     */
    private function validateCredentials(string $sandbox, string $storeId, string $apiKey, string $secret): bool
    {
        return ValidateRequest::getInstance()->validateCredentials();
    }

    /**
     * Hook provides payment option and redirected offered by plugin.
     */
    public function hookPaymentOptions($params)
    {
        // Skip is plugin isn't active.
        if (!$this->active) {
            return;
        }

        // Create empty array to provide payment options active.
        $paymentOptions = [];

        // Add Generic Checkout as payment options if active.
        if (Configuration::get(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            // create a PaymentOption of type Offline
            $genericOption = new PaymentOption();
            $genericOption->setModuleName($this->name);
            $genericOption->setCallToActionText($this->trans('Generic Checkout', [], 'Modules.Ipgcheckout.Front'));
            $genericOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "generic"]));
            $genericOption->setAdditionalInformation($this->additionalInformationGeneric());
            //$genericOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-gateway-generic.svg'));
            $paymentOptions[] = $genericOption;
        }

        // Add Debit Checkout as payment options if active.
        if (Configuration::get(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $debitOption = new PaymentOption();
            $debitOption->setModuleName($this->name);
            $debitOption->setCallToActionText($this->trans('Credit / Debit Card', [], 'Modules.Ipgcheckout.Front'));
            $debitOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "cards"]));
            $debitOption->setAdditionalInformation($this->additionalInformation());
            //$debitOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-credit-card.svg'));
            $paymentOptions[] = $debitOption;
        }

        // Add Apple Pay as payment options if active.
        if (Configuration::get(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $appleOption = new PaymentOption();
            $appleOption->setModuleName($this->name);
            $appleOption->setCallToActionText($this->trans('Apple Pay', [], 'Modules.Ipgcheckout.Front'));
            $appleOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "applepay"]));
            $appleOption->setAdditionalInformation($this->additionalInformation());
            //$appleOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-apple-pay.svg'));
            $paymentOptions[] = $appleOption;
        }

        // Add Google Pay as payment options if active.
        if (Configuration::get(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $googleOption = new PaymentOption();
            $googleOption->setModuleName($this->name);
            $googleOption->setCallToActionText($this->trans('Google Pay', [], 'Modules.Ipgcheckout.Front'));
            $googleOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "googlepay"]));
            $googleOption->setAdditionalInformation($this->additionalInformation());
            //$googleOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-google-pay.svg'));
            $paymentOptions[] = $googleOption;
        }

        // Add Bizum as payment options if active.
        if (Configuration::get(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $bizumOption = new PaymentOption();
            $bizumOption->setModuleName($this->name);
            $bizumOption->setCallToActionText($this->trans('Bizum', [], 'Modules.Ipgcheckout.Front'));
            $bizumOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "bizum"]));
            $bizumOption->setAdditionalInformation($this->additionalInformation());
            //$bizumOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-bizum-pay.png'));
            $paymentOptions[] = $bizumOption;
        }

        // Add iDeal as payment options if active.
        if (Configuration::get(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY) === IPGCheckout::TRUE) {
            $idealOption = new PaymentOption();
            $idealOption->setModuleName($this->name);
            $idealOption->setCallToActionText($this->trans('iDEAL | Wero', [], 'Modules.Ipgcheckout.Front'));
            $idealOption->setAction($this->context->link->getModuleLink($this->name, 'pay', ['option' => "ideal"]));
            $idealOption->setAdditionalInformation($this->additionalInformation());
            //$idealOption->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/option/fiserv-ideal-pay.png'));
            $paymentOptions[] = $idealOption;
        }

        // Return array with payment options active.
        return $paymentOptions;
    }

    /**
     * Additional information used for payment options.
     */
    private function additionalInformation()
    {
        return '<p>' . $this->trans('You will be redirected to an external checkout page.', [], 'Modules.Ipgcheckout.Front') . '</p>';
    }

    /**
     * Additional information used for Generic Checkout
     */
    private function additionalInformationGeneric()
    {
        return '<p>' . $this->trans('You will be redirected to an external checkout page where you will be able to select the other payment methods.', [], 'Modules.Ipgcheckout.Front') . '</p>';
    }

    /**
     * Active new translation system of PrestaShop.
     */
    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    /**
     * Created the custom helper table for storing cart id with corrensponding checkout id (IPG).
     */
    public function createTable()
    {
        $transactionsTable = _DB_PREFIX_ . IPGCheckout::NAME . '_transactions';
        $refundLedgerTable = _DB_PREFIX_ . IPGCheckout::NAME . '_refund_ledger';

        $createdTransactions = DB::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . $transactionsTable . '` (
            cart_id INT(11) NOT NULL,
            transaction_id VARCHAR(255) NOT NULL
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;');

        $createdRefundLedger = DB::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . $refundLedgerTable . '` (
            id_ipg_refund_ledger INT(11) NOT NULL AUTO_INCREMENT,
            id_order INT(11) NOT NULL,
            checkout_id VARCHAR(255) NULL,
            gateway_transaction_id VARCHAR(255) NULL,
            refund_amount DECIMAL(20,6) NOT NULL,
            currency VARCHAR(8) NULL,
            raw_response LONGTEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id_ipg_refund_ledger),
            INDEX idx_id_order (id_order),
            INDEX idx_created_at (created_at)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;');

        return (bool) ($createdTransactions && $createdRefundLedger);
    }

    /**
     * Drop the custom helper table.
     */
    public function dropTable()
    {
        DB::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . IPGCheckout::NAME . '_transactions;');
        DB::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . IPGCheckout::NAME . '_refund_ledger;');
        return true;
    }

    private function getRefundLedgerTableName(): string
    {
        return _DB_PREFIX_ . IPGCheckout::NAME . '_refund_ledger';
    }

    private function ensureRefundLedgerTable(): void
    {
        static $refundLedgerChecked = false;
        if ($refundLedgerChecked) {
            return;
        }

        $table = pSQL($this->getRefundLedgerTableName());
        $exists = DB::getInstance()->getValue("SHOW TABLES LIKE '" . $table . "'");
        if (!$exists) {
            $this->createTable();
        }

        $refundLedgerChecked = true;
    }

     private function roundMoney($amount): float
    {
        return round((float) $amount, 2, PHP_ROUND_HALF_UP);
    }

    private function getRequestedRefundAmount($orderRefundDetails): float
    {
        $productsAmount = isset($orderRefundDetails->amount) ? (float) $orderRefundDetails->amount : 0.0;
        $shippingAmount = isset($orderRefundDetails->shipping_cost_amount) ? (float) $orderRefundDetails->shipping_cost_amount : 0.0;

        return $this->roundMoney($productsAmount + $shippingAmount);
    }

    private function getSelectedRefundQuantities(): array
    {
        $cancelQuantity = Tools::getValue('cancelQuantity');
        if (!is_array($cancelQuantity)) {
            return [];
        }

        $selectedQuantities = [];
        foreach ($cancelQuantity as $orderDetailId => $quantity) {
            $detailId = (int) $orderDetailId;
            $qty = (int) $quantity;
            if ($detailId > 0 && $qty > 0) {
                $selectedQuantities[$detailId] = $qty;
            }
        }

        return $selectedQuantities;
    }

    private function getRequestedRefundProductsAmountFromSelection(Order $order): ?float
    {
        $selectedQuantities = $this->getSelectedRefundQuantities();
        if (empty($selectedQuantities)) {
            return null;
        }

        $orderDetailIds = array_keys($selectedQuantities);
        $sql = 'SELECT id_order_detail, unit_price_tax_incl
                FROM `' . _DB_PREFIX_ . 'order_detail`
                WHERE id_order = ' . (int) $order->id . '
                AND id_order_detail IN (' . implode(',', array_map('intval', $orderDetailIds)) . ')';

        $rows = DB::getInstance()->executeS($sql);
        if (!is_array($rows) || empty($rows)) {
            return null;
        }

        $productsAmount = 0.0;
        foreach ($rows as $row) {
            $detailId = (int) $row['id_order_detail'];
            if (!isset($selectedQuantities[$detailId])) {
                continue;
            }

            $unitPriceTaxIncl = isset($row['unit_price_tax_incl']) ? (float) $row['unit_price_tax_incl'] : 0.0;
            $productsAmount += ($unitPriceTaxIncl * (int) $selectedQuantities[$detailId]);
        }

        return $this->roundMoney($productsAmount);
    }

    private function getDiscountAdjustedRefundAmount(Order $order, $orderRefundDetails): float
    {
        $productsRequested = $this->getRequestedRefundProductsAmountFromSelection($order);
        if ($productsRequested === null) {
            $productsRequestedRaw = isset($orderRefundDetails->amount) ? (float) $orderRefundDetails->amount : 0.0;
            $productsRequested = $this->roundMoney($productsRequestedRaw * $this->getOrderProductsDiscountFactor($order));
        }
        $shippingRequested = isset($orderRefundDetails->shipping_cost_amount) ? (float) $orderRefundDetails->shipping_cost_amount : 0.0;

        return $this->roundMoney($productsRequested + $shippingRequested);
    }

    private function getOrderProductsDiscountFactor(Order $order): float
    {
        $orderProductsGross = $this->roundMoney($order->total_products_wt);
        if ($orderProductsGross <= 0.0) {
            return 1.0;
        }

        $orderDiscounts = $this->roundMoney($order->total_discounts_tax_incl);
        $orderProductsNet = max(0.0, $this->roundMoney($orderProductsGross - $orderDiscounts));

        return $orderProductsNet / $orderProductsGross;
    }

    private function getPaidAmountForOrder(Order $order): float
    {
        $payments = $order->getOrderPayments();
        if (empty($payments)) {
            return $this->roundMoney((float) $order->total_paid_tax_incl);
        }

        $paidAmount = 0.0;
        foreach ($payments as $payment) {
            if (isset($payment->payment_method) && $payment->payment_method !== IPGCheckout::PAYMENT_MATHOD_NAME) {
                continue;
            }
            $paidAmount += isset($payment->amount) ? (float) $payment->amount : 0.0;
        }

        if ($paidAmount <= 0.0) {
            return $this->roundMoney((float) $order->total_paid_tax_incl);
        }

        return $this->roundMoney($paidAmount);
    }

    private function getAlreadyRefundedAmountForOrder(Order $order): float
    {
        $this->ensureRefundLedgerTable();
        $ledgerTable = $this->getRefundLedgerTableName();

        $ledgerSql = 'SELECT COALESCE(SUM(refund_amount), 0)
                      FROM `' . bqSQL($ledgerTable) . '`
                      WHERE id_order = ' . (int) $order->id;

        $refundedAmountFromLedger = $this->roundMoney((float) DB::getInstance()->getValue($ledgerSql));
        if ($refundedAmountFromLedger > 0.0) {
            return $refundedAmountFromLedger;
        }

        // Legacy fallback for historic refunds made before ledger existed.
        $productsSql = 'SELECT COALESCE(SUM(osd.product_quantity * od.unit_price_tax_incl), 0)
                        FROM `' . _DB_PREFIX_ . 'order_slip` os
                        INNER JOIN `' . _DB_PREFIX_ . 'order_slip_detail` osd ON osd.id_order_slip = os.id_order_slip
                        INNER JOIN `' . _DB_PREFIX_ . 'order_detail` od ON od.id_order_detail = osd.id_order_detail
                        WHERE os.id_order = ' . (int) $order->id;

        $shippingSql = 'SELECT COALESCE(SUM(shipping_cost_amount), 0)
                        FROM `' . _DB_PREFIX_ . 'order_slip`
                        WHERE id_order = ' . (int) $order->id;

        $refundedProductsAmount = (float) DB::getInstance()->getValue($productsSql);
        $refundedShippingAmount = (float) DB::getInstance()->getValue($shippingSql);

        $refundedAmount = $this->roundMoney($refundedProductsAmount + $refundedShippingAmount);

        return $this->roundMoney($refundedAmount);
    }

    private function writeRefundLedgerEntry(Order $order, ?string $checkoutId, ?string $gatewayTransactionId, float $refundAmount, ?string $currency, ?array $rawResponse): bool
    {
        $this->ensureRefundLedgerTable();

        $table = bqSQL($this->getRefundLedgerTableName());
        $checkoutValue = $checkoutId !== null ? "'" . pSQL($checkoutId) . "'" : 'NULL';
        $gatewayValue = $gatewayTransactionId !== null ? "'" . pSQL($gatewayTransactionId) . "'" : 'NULL';
        $currencyValue = $currency !== null ? "'" . pSQL($currency) . "'" : 'NULL';
        $rawResponseValue = $rawResponse !== null ? "'" . pSQL(json_encode($rawResponse)) . "'" : 'NULL';
        $createdAtValue = "'" . pSQL(date('Y-m-d H:i:s')) . "'";

        $sql = 'INSERT INTO `' . $table . '`
                (id_order, checkout_id, gateway_transaction_id, refund_amount, currency, raw_response, created_at)
                VALUES (
                    ' . (int) $order->id . ',
                    ' . $checkoutValue . ',
                    ' . $gatewayValue . ',
                    ' . (float) $this->roundMoney($refundAmount) . ',
                    ' . $currencyValue . ',
                    ' . $rawResponseValue . ',
                    ' . $createdAtValue . '
                )';

        $written = (bool) DB::getInstance()->execute($sql);
        if (!$written) {
            PrestaShopLogger::addLog(
                'Refund ledger SQL insert failed for order (' . $order->id . '). DB error: ' . DB::getInstance()->getMsgError(),
                3,
                0,
                IPGCheckout::NAME,
                $order->id
            );
        }

        return $written;
    }

    private function getRefundBudget(Order $order): array
    {
        $paidAmount = $this->getPaidAmountForOrder($order);
        $alreadyRefundedAmount = $this->getAlreadyRefundedAmountForOrder($order);
        $remainingAmount = max(0.0, $this->roundMoney($paidAmount - $alreadyRefundedAmount));

        return [
            'paid' => $paidAmount,
            'already_refunded' => $alreadyRefundedAmount,
            'remaining' => $remainingAmount,
        ];
    }

    private function logRefundDiagnostics(Order $order, $orderRefundDetails, array $refundBudget, float $requestedAmountRaw, float $requestedAmountAdjusted): void
    {
        $payments = $order->getOrderPayments();
        $paymentRows = [];
        foreach ($payments as $payment) {
            $paymentRows[] = [
                'id' => isset($payment->id) ? (int) $payment->id : null,
                'payment_method' => isset($payment->payment_method) ? (string) $payment->payment_method : null,
                'amount' => isset($payment->amount) ? $this->roundMoney($payment->amount) : null,
                'transaction_id' => isset($payment->transaction_id) ? (string) $payment->transaction_id : null,
            ];
        }

        $logData = [
            'order_id' => (int) $order->id,
            'requested' => [
                'products_amount' => isset($orderRefundDetails->amount) ? $this->roundMoney($orderRefundDetails->amount) : 0.0,
                'shipping_amount' => isset($orderRefundDetails->shipping_cost_amount) ? $this->roundMoney($orderRefundDetails->shipping_cost_amount) : 0.0,
                'total_requested_raw' => $requestedAmountRaw,
                'total_requested_adjusted' => $requestedAmountAdjusted,
                'selected_quantities' => $this->getSelectedRefundQuantities(),
            ],
            'budget' => $refundBudget,
            'already_refunded_source' => $refundBudget['already_refunded'] > 0.0 ? 'ledger_or_legacy' : 'none',
            'order_totals' => [
                'total_paid_tax_incl' => $this->roundMoney($order->total_paid_tax_incl),
                'total_paid_real' => $this->roundMoney($order->total_paid_real),
                'total_products_wt' => $this->roundMoney($order->total_products_wt),
                'total_discounts_tax_incl' => $this->roundMoney($order->total_discounts_tax_incl),
                'total_shipping_tax_incl' => $this->roundMoney($order->total_shipping_tax_incl),
                'discount_factor' => $this->getOrderProductsDiscountFactor($order),
            ],
            'payments' => $paymentRows,
            'module_payment_method_name' => IPGCheckout::PAYMENT_MATHOD_NAME,
        ];

        PrestaShopLogger::addLog('Refund diagnostics: ' . json_encode($logData), 1, 0, IPGCheckout::NAME, $order->id);
    }

    private function refundWrite($order, $transaction_id, $refundedResponse = null)
    {
        $message = '';
        if ($refundedResponse && is_array($refundedResponse)) {
            $amount = $refundedResponse['transactionAmount']['total'];
            $currency = $refundedResponse['transactionAmount']['currency'];
            $message = sprintf('Refunded %s %s (Gateway Transaction ID: %s)', $currency, $amount, $transaction_id);
        }
        RefundRequestHandler::writeMessage($order, $message);
    }

    private function refundExceptionWrite($order, $transaction_id, $e)
    {
        $message = sprintf('Refunding failed (Gateway Transaction ID: %s)%s', $transaction_id, PHP_EOL);
        if ($e instanceof \GuzzleHttp\Exception\RequestException && $e->hasResponse()) {
            $exceptionBody = (string) $e->getResponse()->getBody();
            // decode once and guard nested keys to avoid notices
            $decoded = $exceptionBody ? json_decode($exceptionBody, true) : null;
            // add apiTraceId if available for better tracking in logs
            $traceId = is_array($decoded) ? ($decoded['apiTraceId'] ?? null) : null;
            if (!empty($traceId)) {
                $message .= sprintf('Trace ID: %s%s', $traceId, PHP_EOL);
            }
            $errorMessage = null;
            if (is_array($decoded)) {
                if (isset($decoded['error']['details'][0]['message'])) {
                    $errorMessage = $decoded['error']['details'][0]['message'];
                } elseif (isset($decoded['error']['message'])) {
                    $errorMessage = $decoded['error']['message'];
                } elseif (isset($decoded['errors'][0]['detail'])) {
                    $errorMessage = $decoded['errors'][0]['detail'];
                }
            }
            if (!empty($errorMessage)) {
                $message .= sprintf('Error message: %s%s', $errorMessage, PHP_EOL);
            }
        }else {
            $message .= sprintf('Exception: %s%s', $e->getMessage(), PHP_EOL);
        }
        RefundRequestHandler::writeMessage($order, $message);
    }


    private function refundLog($order, $transaction_id, $e)
    {
        $messages = [];
        $messages[] = 'Order (' . $order->id . ') failed refund for products in order (Gateway Transaction ID: ' . $transaction_id . ')';
        if ($e instanceof \GuzzleHttp\Exception\RequestException && $e->hasResponse()) {
            $exceptionBody = (string) $e->getResponse()->getBody();
            !empty($exceptionBody) ? $messages[] = 'Order (' . $order->id . ') refund exception response: ' . $exceptionBody : null;
        } else {
            $messages[] = 'Order (' . $order->id . ') refund exception: ' . $e->getMessage();
        }

        foreach($messages as $message) {
            PrestaShopLogger::addLog($message, 3, 0, IPGCheckout::NAME, $order->id);
        }
    }

    private function preventPrestaShopRefund($e, $params): void {
        // Nulling conversion_rate is only safe accessible way to arrest the
        // PrestaShop refund processes, ie. reconciling stock, displaying flash messages,
        // creating order slips, etc. This is a workaround to prevent PrestaShop from
        // processing the refund when the refund fails in the IPG system.
        // Without this confusing information is prsented to the user indicating a
        // successful refund when one has not taken place
        $_SESSION['hook_order_slip_error'] = 'Refund failed';
        $params['object']->conversion_rate = null;
    }


    public function hookActionObjectOrderSlipAddBefore($params)
    {
        $orderRefundDetails = isset($params['object']) ? $params['object'] : null;
        if (is_object($orderRefundDetails) && isset($orderRefundDetails->id_order)) {
            $order = new Order((int)$orderRefundDetails->id_order);
            if (empty($order->getOrderPayments())) {
                PrestaShopLogger::addLog('Refund attempt. No payment found for order ' . $order->id, 2, 0, IPGCheckout::NAME, $order->id);
                return;
            }
            $amountRaw = $this->getRequestedRefundAmount($orderRefundDetails);
            $amount = $this->getDiscountAdjustedRefundAmount($order, $orderRefundDetails);
            $refundBudget = $this->getRefundBudget($order);
            $this->logRefundDiagnostics($order, $orderRefundDetails, $refundBudget, $amountRaw, $amount);
            if ($amount <= 0.0) {
                PrestaShopLogger::addLog('Refund blocked for order (' . $order->id . '): requested amount must be greater than zero.', 2, 0, IPGCheckout::NAME, $order->id);
                $this->preventPrestaShopRefund(new Exception('Invalid refund amount'), $params);
                return;
            }

            if ($amount > $refundBudget['remaining']) {
                $message = sprintf(
                    'Refund blocked for order (%d): requested %.2f exceeds remaining refundable %.2f (paid %.2f, already refunded %.2f).',
                    (int) $order->id,
                    $amount,
                    $refundBudget['remaining'],
                    $refundBudget['paid'],
                    $refundBudget['already_refunded']
                );
                PrestaShopLogger::addLog($message, 2, 0, IPGCheckout::NAME, $order->id);
                RefundRequestHandler::writeMessage($order, $message);
                $this->preventPrestaShopRefund(new Exception('Refund amount exceeds remaining refundable amount'), $params);
                return;
            }

            $checkout_id = null;
            try {
                $transaction_id = null;
                $checkout_id = $order->getOrderPayments()[0]->transaction_id;
                $transaction_id = CheckoutRequestHandler::getInstance()->getTransactionId($checkout_id);
                $refundedResponse = json_decode(RefundRequestHandler::getInstance()->request($order, $transaction_id, $amount), true);

                $ledgerAmount = $amount;
                $ledgerCurrency = null;
                if (is_array($refundedResponse)) {
                    if (isset($refundedResponse['transactionAmount']['total'])) {
                        $ledgerAmount = (float) $refundedResponse['transactionAmount']['total'];
                    }
                    if (isset($refundedResponse['transactionAmount']['currency'])) {
                        $ledgerCurrency = (string) $refundedResponse['transactionAmount']['currency'];
                    }
                }

                $written = $this->writeRefundLedgerEntry(
                    $order,
                    $checkout_id,
                    $transaction_id,
                    $ledgerAmount,
                    $ledgerCurrency,
                    is_array($refundedResponse) ? $refundedResponse : null
                );
                if (!$written) {
                    PrestaShopLogger::addLog('Refund ledger write failed for order (' . $order->id . ') after successful gateway refund.', 3, 0, IPGCheckout::NAME, $order->id);
                }

                $this->refundWrite($order, $transaction_id, $refundedResponse);
            }  catch (Exception $e) {
                // Log and add message when refund fails.
                $ref = $transaction_id ?? $checkout_id ?? 'unknown';
                $this->refundLog($order, $transaction_id, $e);
                $this->refundExceptionWrite($order, $ref, $e);
                $this->preventPrestaShopRefund($e, $params);
            }
        } else {
            PrestaShopLogger::addLog('OrderSlipAddBefore: no object', 1, 0, IPGCheckout::NAME, 0);
        }
    }

    /**
     * Looking for 'hook_order_slip_error' in session. If is present show error message.
     */
    public function hookDisplayAdminOrderTop($params)
    {
        if (isset($_SESSION['hook_order_slip_error'])) {
            unset($_SESSION['hook_order_slip_error']);
            return $this->displayError($this->trans("Refund failed! Manual treatment may be necessary!", [], 'Modules.Ipgcheckout.Admin'));
        }
    }

    /**
     * Added css
     */
    public function hookDisplayBackOfficeHeader($params)
    {
        if (Tools::getValue('configure') === $this->name) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
        }
    }

    /**
     * Display transaction detail.
     */
    public function hookDisplayAdminOrderSideBottom($params)
    {
        // Get order id.
        $order = new Order($params['id_order']);
        // Skip if order has no payments.
        if (count($order->getOrderPayments()) <= 0) {
            return;
        }
        // Skip if order has no matching payment to IPG.
        if ($order->getOrderPayments()[0]) {
            $payment = new OrderPayment($order->getOrderPayments()[0]->id);
            if ($payment->payment_method !== IPGCheckout::PAYMENT_MATHOD_NAME) {
                return;
            }
        }
        // Get checkout id.
        $checkout_id = $order->getOrderPayments()[0]->transaction_id;
        // Request current status.
        $response = CheckoutRequestHandler::getInstance()->checkoutStatus($checkout_id);
        // Decode current status.
        $status = json_decode($response, true);
        // Preparte data for template.
        $this->context->smarty->assign([
            'checkout_id' => $checkout_id,
            'trace_id' => $status['ipgTransactionDetails']['apiTraceId'],
            'paymentMethodType' => $status['paymentMethodUsed']['paymentMethodType'],
            'status' => $status,
            'response' => $response
        ]);
        // Return response of template.
        return $this->display(__FILE__, 'views/templates/admin/orderSide.tpl');
    }

    protected function buildToggleSelectField(string $label, string $name, bool $required = true): array
    {
        return [
            'type'     => 'select',
            'label'    => $label,
            'name'     => $name,
            'required' => $required,
            'options'  => [
                'query' => [
                    [
                        'id_option' => 'TRUE',
                        'name'      => $this->trans('Active', [], 'Modules.Ipgcheckout.Admin'),
                    ],
                    [
                        'id_option' => 'FALSE',
                        'name'      => $this->trans('Deactivated', [], 'Modules.Ipgcheckout.Admin'),
                    ],
                ],
                'id'   => 'id_option',
                'name' => 'name',
            ],
        ];
    }


    /**
     * Performed on installing plugin. Not on updating
     */
    public function install()
    {
        return (
            parent::install()
            // Create custom table
            && $this->createTable()
            // Register hooks
            && $this->registerHook('paymentOptions')
            && $this->registerHook('displayAdminOrderSideBottom')
            && $this->registerHook('displayAdminOrderTop')
            && $this->registerHook('displayBackOfficeHeader')
            && $this->registerHook('actionObjectOrderSlipAddBefore')
            // Set default configurations
            && Configuration::updateValue(IPGCheckout::NAME_KEY, IPGCheckout::NAME)
            && Configuration::updateValue(IPGCheckout::STORE_ID_KEY, IPGCheckout::STORE_ID)
            && Configuration::updateValue(IPGCheckout::API_KEY_KEY, IPGCheckout::API_KEY)
            && Configuration::updateValue(IPGCheckout::SANDBOX_KEY, IPGCheckout::SANDBOX)
            && Configuration::updateValue(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY, IPGCheckout::TRUE)
            && Configuration::updateValue(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY, IPGCheckout::FALSE)
            && Configuration::updateValue(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY, IPGCheckout::FALSE)
        );
    }

    /**
     * Performed of deleting plugin.
     */
    public function uninstall()
    {
        return (
            parent::uninstall()
            // Drop custom table.
            && $this->dropTable()
            // Unregister hooks.
            && $this->unregisterHook('paymentOptions')
            && $this->unregisterHook('displayAdminOrderSideBottom')
            && $this->unregisterHook('displayAdminOrderTop')
            && $this->unregisterHook('displayBackOfficeHeader')
            && $this->unregisterHook('actionObjectOrderSlipAddBefore')
            // Delete configurations.
            && Configuration::deleteByName(IPGCheckout::NAME_KEY)
            && Configuration::deleteByName(IPGCheckout::STORE_ID_KEY)
            && Configuration::deleteByName(IPGCheckout::API_KEY_KEY)
            && Configuration::deleteByName(IPGCheckout::SECRET_KEY)
            && Configuration::deleteByName(IPGCheckout::SANDBOX_KEY)
            && Configuration::deleteByName(IPGCheckout::GENERIC_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::DEBIT_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::APPLE_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::GOOGLE_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::BIZUM_CHECKOUT_ACTIVE_KEY)
            && Configuration::deleteByName(IPGCheckout::IDEAL_CHECKOUT_ACTIVE_KEY)
        );
    }
}