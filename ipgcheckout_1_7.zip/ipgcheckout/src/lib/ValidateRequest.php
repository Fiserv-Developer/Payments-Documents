<?php

use GuzzleHttp\Exception\ClientException;

require_once dirname(__FILE__) . '/../../vendor/autoload.php';
class ValidateRequest extends RequestHandler {
    /**
     * TODO: Check if still needed.
     */
    public function __construct(string $storeId, string $apiKey, string $secret) {
        parent::__construct($storeId, $apiKey, $secret);
    }

    /**
     * Create a new instance of CheckoutRequestHandler with environment configuration
     */
    public static function getInstance(): ValidateRequest {
        return new ValidateRequest(
            Configuration::get(IPGCheckout::STORE_ID_KEY),
            Configuration::get(IPGCheckout::API_KEY_KEY),
            Configuration::get(IPGCheckout::SECRET_KEY)
        );
    }

    /**
     * Get Uri depending on sandbox mode.
     */
    protected function getCheckoutUri() {
        if (Configuration::get(IPGCheckout::SANDBOX_KEY) === 'FALSE') {
            return 'https://prod.emea.api.fiservapps.com/ipp/payments-gateway/v2/card-information';
        }

        return 'https://prod.emea.api.fiservapps.com/sandbox/ipp/payments-gateway/v2/card-information';
    }

    /**
     * Request sesnsless payment card number.
     */
    public function request() {
        $time = (int) (microtime(true) * 1000);

        $clientRequestId = CheckoutRequestHandler::generateUuid();

        $requestBody = json_encode([
            'storeId'     => $this->storeId,
            'paymentCard' => [
                'number' => 'NL91ABNA0417164300'
            ],
            'paymentCardEncrypted' => [
                'encryptionType' => 'JWE',
                'encryptedData'  => 'asdf',
                'keyId'          => 'asdf'
            ]
        ]);

        $messageSignature = $this->sign($clientRequestId, $time, $requestBody);

        $client = new \GuzzleHttp\Client();
        $response = $client->post($this->getCheckoutUri(), [
            'body'    => $requestBody,
            'headers' => [
                'accept'                                        => 'application/json',
                'content-type'                                  => 'application/json',
                'Api-Key'                                       => $this->apiKey,
                'Client-Request-Id'                             => $clientRequestId,
                'Message-Signature'                             => $messageSignature,
                'Timestamp'                                     => $time,
                'User-Agent'                                    => CheckoutRequestHandler::HEADER_USER_AGENT,
                CheckoutRequestHandler::SHOPPLUGIN_HEADER_FIELD => CheckoutRequestHandler::HEADER_X_SHOPPLUGIN
            ],
        ]);

        return $response->getBody()->getContents();
    }

    /**
     * To be used to validate current API Key and secret.
     */
    public function validateCredentials(): bool {
        try {
            $this->request();
        } catch (ClientException $e) {
            return !in_array($e->getResponse()->getStatusCode(), [401, 403]);
        }

        return true;
    }
}
